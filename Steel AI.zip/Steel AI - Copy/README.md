# Steel AI

This is an AI built by GodSteelGaming. It is a work in progress, so it doesn't do much.

